document.addEventListener("DOMContentLoaded", function () {
    const boardElement = document.getElementById("board");
    const messageElement = document.getElementById("message");
    const resetButton = document.getElementById("reset-button");

    let currentPlayer = "X";
    let board = ["", "", "", "", "", "", "", "", ""];
    let gameActive = true;

    function checkWinner() {
        const winPatterns = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6],
        ];

        for (let pattern of winPatterns) {
            const [a, b, c] = pattern;
            if (board[a] && board[a] === board[b] && board[a] === board[c]) {
                gameActive = false;
                document.getElementById(a).classList.add("winner");
                document.getElementById(b).classList.add("winner");
                document.getElementById(c).classList.add("winner");
                messageElement.textContent = `${currentPlayer} wins!`;
                showGameOverScreen(`${currentPlayer} wins!`);
                return;
            }
        }

        if (!board.includes("") && gameActive) {
            gameActive = false;
            messageElement.textContent = "It's a draw!";
            showGameOverScreen("It's a draw!");
        }
    }

    function handleCellClick(event) {
        const cell = event.target;
        const cellIndex = cell.id;

        if (board[cellIndex] === "" && gameActive) {
            board[cellIndex] = currentPlayer;
            cell.textContent = currentPlayer;
            cell.classList.add(currentPlayer);

            checkWinner();

            currentPlayer = currentPlayer === "X" ? "O" : "X";
        }
    }

    function showGameOverScreen(messageText) {
        const gameOverScreen = document.createElement("div");
        gameOverScreen.classList.add("game-over-screen");
        const messageElement = document.createElement("p");
        messageElement.textContent = messageText;
        const newGameButton = document.createElement("button");
        newGameButton.textContent = "New Game";
        newGameButton.addEventListener("click", startNewGame);

        gameOverScreen.appendChild(messageElement);
        gameOverScreen.appendChild(newGameButton);
        document.body.appendChild(gameOverScreen);
    }

    function startNewGame() {
        const gameOverScreen = document.querySelector(".game-over-screen");
        if (gameOverScreen) {
            gameOverScreen.remove();
        }

        currentPlayer = "X";
        board = ["", "", "", "", "", "", "", "", ""];
        gameActive = true;

        boardElement.innerHTML = ""; // Clear the board

        for (let i = 0; i < 9; i++) {
            const cell = document.createElement("div");
            cell.classList.add("cell");
            cell.id = i;
            cell.addEventListener("click", handleCellClick);
            boardElement.appendChild(cell);
        }

        messageElement.textContent = "";
    }

    resetButton.addEventListener("click", startNewGame);
});
